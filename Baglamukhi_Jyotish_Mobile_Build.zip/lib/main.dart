import 'package:flutter/material.dart';
import 'screens/home_screen.dart';

void main() => runApp(const BaglamukhiJyotishApp());

class BaglamukhiJyotishApp extends StatelessWidget {
  const BaglamukhiJyotishApp({super.key});

  @override
  Widget build(BuildContext context) {
    const gold = Color(0xFFE9BC61);
    return MaterialApp(
      title: 'Baglamukhi Jyotish',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: gold),
        scaffoldBackgroundColor: const Color(0xFFF7F4EE),
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFF111A32),
          foregroundColor: Colors.white,
        ),
      ),
      home: const HomeScreen(),
    );
  }
}
