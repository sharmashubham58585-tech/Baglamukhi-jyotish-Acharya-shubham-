import '../models/birth_details.dart';

class KundaliService {
  /// Free starter: validates and holds birth input only.
  /// Real planetary positions must be supplied by a tested ephemeris engine.
  /// This service deliberately does not invent planetary positions.
  Map<String, String> prepareInput(BirthDetails details) => {
        'name': details.name,
        'date': '${details.birthDate.year.toString().padLeft(4, '0')}-'
            '${details.birthDate.month.toString().padLeft(2, '0')}-'
            '${details.birthDate.day.toString().padLeft(2, '0')}',
        'time': details.birthTime,
        'place': details.birthPlace,
        'calculationStatus': 'engine_not_connected',
      };
}
