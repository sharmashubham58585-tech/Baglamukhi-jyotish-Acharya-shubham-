import 'package:flutter/material.dart';
import '../models/birth_details.dart';
import '../services/kundali_service.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _index = 0;
  final _formKey = GlobalKey<FormState>();
  final _name = TextEditingController();
  final _place = TextEditingController(text: 'ढढौरा, छतरपुर, मध्य प्रदेश');
  DateTime _date = DateTime(1997, 6, 9);
  TimeOfDay _time = const TimeOfDay(hour: 20, minute: 10);
  String? _message;

  @override
  void dispose() {
    _name.dispose();
    _place.dispose();
    super.dispose();
  }

  String get _dateText =>
      '${_date.day.toString().padLeft(2, '0')}/'
      '${_date.month.toString().padLeft(2, '0')}/${_date.year}';

  String get _timeText =>
      '${_time.hour.toString().padLeft(2, '0')}:'
      '${_time.minute.toString().padLeft(2, '0')}';

  Future<void> _pickDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _date,
      firstDate: DateTime(1900),
      lastDate: DateTime.now(),
    );
    if (picked != null) setState(() => _date = picked);
  }

  Future<void> _pickTime() async {
    final picked = await showTimePicker(context: context, initialTime: _time);
    if (picked != null) setState(() => _time = picked);
  }

  void _submit() {
    if (!_formKey.currentState!.validate()) return;
    final details = BirthDetails(
      name: _name.text.trim(),
      birthDate: _date,
      birthTime: _timeText,
      birthPlace: _place.text.trim(),
    );
    final data = KundaliService().prepareInput(details);
    setState(() {
      _index = 1;
      _message = 'जन्म विवरण तैयार है: ${data['date']} • ${data['time']}\\n'
          'स्थान: ${data['place']}\\n\\n'
          'ध्यान दें: वास्तविक ग्रह-गणना इंजन अभी नहीं जुड़ा है। '
          'इसलिए यह ऐप अभी ग्रहों की स्थिति या भविष्यवाणी गढ़कर नहीं दिखाता।';
    });
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      _homePage(),
      _kundaliPage(),
      _reportPage(),
      _servicesPage(),
    ];
    return Scaffold(
      appBar: AppBar(
        title: const Row(children: [
          Icon(Icons.auto_awesome, color: Color(0xFFE9BC61)),
          SizedBox(width: 10),
          Text('Baglamukhi Jyotish',
              style: TextStyle(fontWeight: FontWeight.bold)),
        ]),
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [pages[_index]],
        ),
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (i) => setState(() => _index = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), label: 'होम'),
          NavigationDestination(icon: Icon(Icons.auto_graph), label: 'कुंडली'),
          NavigationDestination(icon: Icon(Icons.article_outlined), label: 'रिपोर्ट'),
          NavigationDestination(icon: Icon(Icons.grid_view), label: 'सेवाएँ'),
        ],
      ),
    );
  }

  Widget _homePage() => Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(22),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(22),
              gradient: const LinearGradient(
                colors: [Color(0xFF10182E), Color(0xFF303C5B)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            ),
            child: const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('ॐ ह्लीं बगलामुख्यै नमः',
                    style: TextStyle(
                        color: Color(0xFFE9BC61),
                        fontWeight: FontWeight.bold,
                        fontSize: 17)),
                SizedBox(height: 12),
                Text('वैदिक ज्योतिष, सरल हिंदी में',
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 24,
                        fontWeight: FontWeight.w800)),
                SizedBox(height: 8),
                Text('जन्मकुंडली • विवाह • करियर • धन • गोचर',
                    style: TextStyle(color: Colors.white70, height: 1.5)),
              ],
            ),
          ),
          const SizedBox(height: 18),
          Card(
            color: Colors.white,
            elevation: 0,
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Form(
                key: _formKey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('जन्म विवरण',
                        style: TextStyle(
                            fontSize: 21, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 14),
                    TextFormField(
                      controller: _name,
                      decoration: const InputDecoration(labelText: 'पूरा नाम'),
                      validator: (v) =>
                          v == null || v.trim().isEmpty ? 'नाम भरें' : null,
                    ),
                    const SizedBox(height: 12),
                    OutlinedButton.icon(
                      onPressed: _pickDate,
                      icon: const Icon(Icons.calendar_month),
                      label: Text('जन्म तिथि: $_dateText'),
                    ),
                    OutlinedButton.icon(
                      onPressed: _pickTime,
                      icon: const Icon(Icons.schedule),
                      label: Text('जन्म समय: $_timeText'),
                    ),
                    const SizedBox(height: 10),
                    TextFormField(
                      controller: _place,
                      decoration: const InputDecoration(
                          labelText: 'जन्म स्थान', hintText: 'गाँव, जिला, राज्य'),
                      validator: (v) => v == null || v.trim().isEmpty
                          ? 'जन्म स्थान भरें'
                          : null,
                    ),
                    const SizedBox(height: 16),
                    SizedBox(
                      width: double.infinity,
                      child: FilledButton.icon(
                        onPressed: _submit,
                        icon: const Icon(Icons.auto_awesome),
                        label: const Text('कुंडली शुरू करें'),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          const SizedBox(height: 12),
          const Text('आपकी ज्योतिषीय सेवाएँ',
              style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
          const SizedBox(height: 10),
          GridView.count(
            crossAxisCount: 2,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            crossAxisSpacing: 10,
            mainAxisSpacing: 10,
            childAspectRatio: 1.65,
            children: const [
              _FeatureCard(Icons.favorite_outline, 'विवाह योग'),
              _FeatureCard(Icons.work_outline, 'करियर और धन'),
              _FeatureCard(Icons.calendar_month, 'पंचांग और मुहूर्त'),
              _FeatureCard(Icons.home_work_outlined, 'वास्तु मार्गदर्शन'),
            ],
          ),
        ],
      );

  Widget _kundaliPage() => Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('जन्म कुंडली',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(18),
            ),
            child: Column(
              children: [
                const Icon(Icons.auto_graph,
                    size: 70, color: Color(0xFFB17A20)),
                const SizedBox(height: 12),
                const Text('आपकी कुंडली यहाँ दिखाई जाएगी',
                    style:
                        TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                const Text(
                  'अभी गणना इंजन नहीं जुड़ा है। सही ग्रह-स्थिति के लिए मुफ्त/लाइसेंस-अनुकूल गणना इंजन को जाँचकर जोड़ना अगला चरण है।',
                  textAlign: TextAlign.center,
                  style: TextStyle(height: 1.5),
                ),
                if (_message != null) ...[
                  const Divider(height: 28),
                  Text(_message!, style: const TextStyle(height: 1.5)),
                ],
              ],
            ),
          ),
        ],
      );

  Widget _reportPage() => const _InfoPage(
        title: 'ज्योतिष रिपोर्ट',
        icon: Icons.article_outlined,
        description:
            'विवाह, करियर, धन और ग्रह दशा की रिपोर्ट का ढाँचा तैयार है। वास्तविक रिपोर्ट गणना इंजन जुड़ने के बाद ही दिखाई जाएगी।',
      );

  Widget _servicesPage() => const Column(
        children: [
          _ServiceTile(Icons.calendar_month, 'पंचांग और मुहूर्त'),
          _ServiceTile(Icons.favorite_outline, 'गुण मिलान'),
          _ServiceTile(Icons.home_work_outlined, 'वास्तु मार्गदर्शन'),
          _ServiceTile(Icons.chat_outlined, 'AI ज्योतिष सलाहकार'),
          SizedBox(height: 12),
          Text(
            'ये शुरुआती सेक्शन हैं। अगले संस्करण में हर सेवा की वास्तविक कार्यक्षमता जोड़ी जाएगी।',
            style: TextStyle(color: Colors.black54),
          ),
        ],
      );
}

class _FeatureCard extends StatelessWidget {
  const _FeatureCard(this.icon, this.title);
  final IconData icon;
  final String title;

  @override
  Widget build(BuildContext context) => Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: const Color(0xFFE9DFC9)),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: const Color(0xFFB17A20), size: 27),
            const SizedBox(height: 8),
            Text(title, style: const TextStyle(fontWeight: FontWeight.w600)),
          ],
        ),
      );
}

class _InfoPage extends StatelessWidget {
  const _InfoPage(
      {required this.title, required this.icon, required this.description});
  final String title;
  final IconData icon;
  final String description;

  @override
  Widget build(BuildContext context) => Card(
        color: Colors.white,
        elevation: 0,
        child: Padding(
          padding: const EdgeInsets.all(22),
          child: Column(
            children: [
              Icon(icon, size: 54, color: const Color(0xFFB17A20)),
              const SizedBox(height: 12),
              Text(title,
                  style: const TextStyle(
                      fontSize: 22, fontWeight: FontWeight.bold)),
              const SizedBox(height: 10),
              Text(description,
                  textAlign: TextAlign.center,
                  style: const TextStyle(height: 1.6)),
            ],
          ),
        ),
      );
}

class _ServiceTile extends StatelessWidget {
  const _ServiceTile(this.icon, this.title);
  final IconData icon;
  final String title;

  @override
  Widget build(BuildContext context) => Card(
        color: Colors.white,
        elevation: 0,
        child: ListTile(
          leading: Icon(icon, color: const Color(0xFFB17A20)),
          title: Text(title),
          trailing: const Icon(Icons.chevron_right),
          onTap: () => ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('$title अगले चरण में जोड़ा जाएगा।')),
          ),
        ),
      );
}
