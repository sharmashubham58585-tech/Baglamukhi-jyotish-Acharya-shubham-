class BirthDetails {
  const BirthDetails({
    required this.name,
    required this.birthDate,
    required this.birthTime,
    required this.birthPlace,
  });

  final String name;
  final DateTime birthDate;
  final String birthTime;
  final String birthPlace;
}
